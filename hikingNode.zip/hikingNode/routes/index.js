var express = require('express');
var router = express.Router();


function trailsObject (pTrail, pCity, pDifficulty, pRating) {
    this.Trail = pTrail;
    this.City = pCity;
    this.Difficulty = pDifficulty;
    this.Rating = pRating;
}

trailsArrayS = [];  
trailsArrayS.push(new trailsObject("Poo Poo Point", "Seattle", "Medium", "3 star"))


/* GET home page. */
router.get('/', function(req, res, next) { 
res.sendFile('index.html');
});

/* GET all Trails data */
router.get('/getAllTrails', function(req, res) {
  res.status(200).json(trailsArrayS);
});

module.exports = router;
trailsObject