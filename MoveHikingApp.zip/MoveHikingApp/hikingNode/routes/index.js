var express = require('express');
var router = express.Router();

let trailsArrayS = [];

function trailsObject (pTrail, pCity, pDifficulty, pRating) {
    this.Trail = pTrail;
    this.City = pCity;
    this.Difficulty = pDifficulty;
    this.Rating = pRating;
}

/* GET home page. */
router.get('/', function(req, res, next) { 
  res.sendFile('index.html');
  });
  
  /* GET all Trails data */
  router.get('/getAllTrails', function(req, res) {
    res.status(200).json(trailsArrayS);
  });
  
  /* Add one new note */
  router.post('/AddTrails', function(req, res) {
    //const newTrail = req.body;
    trailsArrayS.push(req.body);
    res.status(200); // 200 == OK
  });

  router.delete('/deleteTrail', function(result, res) {
    console.log("Inside deleteTrail. Trail to delete: ", result.body);
    let found = false;
    let obj = result.body;
    let trailName = obj.trailName;
    console.log("Trail name = ", trailName);

    for(let i =0; i < trailsArrayS.length; i++) // find the match
    {
      if( trailName === trailsArrayS[i].Trail){
        trailsArrayS.splice(i,1);
        console.log("Trail Deleted");
          found = true;
          break;
        }
      }
      if(!found) {
        console.log("Trail not found");
        res.status(500).json("Trail \'" + trailName + "\' not found." );
      }
       else
      {
        console.log("Sending 200");
        res.status(200).json("Trail \'" + trailName + "\' successfully deleted." );
      }
  });
  
  module.exports = router;
  trailsObject